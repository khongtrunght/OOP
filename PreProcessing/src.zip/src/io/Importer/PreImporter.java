package io.Importer;

public interface PreImporter {
    String fetchDoc();
}
