package io.Importer;

public class KeyboardImporter implements PreImporter{
    @Override
    public String fetchDoc() {
        return "Mot hai ba bon nam sau\n Bay tam";
    }
}
