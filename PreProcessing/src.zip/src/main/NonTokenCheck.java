package main;

public class NonTokenCheck {

    public NonTokenCheck() {
    }
}
