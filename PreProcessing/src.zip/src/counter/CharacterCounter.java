package counter;

public class CharacterCounter implements Counter{

    @Override
    public Integer count(String doc) {
        return null;
    }
}
