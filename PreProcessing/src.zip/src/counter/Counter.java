package counter;

public interface Counter {
    public Integer count(String doc);
}
