package counter;

public class WordCounter implements Counter {

    @Override
    public Integer count(String doc) {
        return null;
    }
}
