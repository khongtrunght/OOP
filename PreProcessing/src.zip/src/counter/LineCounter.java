package counter;

public class LineCounter implements Counter{


    @Override
    public Integer count(String doc) {

    }
}
